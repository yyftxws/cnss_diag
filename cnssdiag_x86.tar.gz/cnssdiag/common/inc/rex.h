#ifndef REX_H
#define REX_H

/*----------------------------------------------------------------------------
 Copyright (c) 2007 Qualcomm Technologies, Inc.  All Rights Reserved.  
 Qualcomm Technologies Proprietary and Confidential. 
----------------------------------------------------------------------------*/
  
/// @todo RJS !!! Fix
#define rex_task_lock( )
#define rex_task_free( )
typedef dword   rex_sigs_type;


#endif /* REX_H */
